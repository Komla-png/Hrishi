from flask import Flask, render_template, request, redirect, session, jsonify
import sqlite3, os, secrets, re
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

app = Flask(__name__)

# Secure secret key - generate if not exists
SECRET_KEY_FILE = "instance/.secret_key"
def get_secret_key():
    os.makedirs("instance", exist_ok=True)
    if os.path.exists(SECRET_KEY_FILE):
        with open(SECRET_KEY_FILE, "r") as f:
            return f.read().strip()
    key = secrets.token_hex(32)
    with open(SECRET_KEY_FILE, "w") as f:
        f.write(key)
    return key

app.secret_key = get_secret_key()

# Secure session configuration
app.config.update(
    SESSION_COOKIE_SECURE=False,  # Set True in production with HTTPS
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8)
)

DB_PATH = "instance/academy.db"

# Login attempt tracking (simple in-memory rate limiting)
login_attempts = {}
MAX_LOGIN_ATTEMPTS = 5
LOCKOUT_TIME = 300  # 5 minutes in seconds

def is_locked_out(ip):
    if ip in login_attempts:
        attempts, lockout_time = login_attempts[ip]
        if lockout_time and datetime.now().timestamp() < lockout_time:
            return True
        if lockout_time and datetime.now().timestamp() >= lockout_time:
            login_attempts[ip] = (0, None)
    return False

def record_failed_attempt(ip):
    attempts, _ = login_attempts.get(ip, (0, None))
    attempts += 1
    if attempts >= MAX_LOGIN_ATTEMPTS:
        login_attempts[ip] = (attempts, datetime.now().timestamp() + LOCKOUT_TIME)
    else:
        login_attempts[ip] = (attempts, None)

def clear_attempts(ip):
    if ip in login_attempts:
        del login_attempts[ip]

# Input sanitization
def sanitize_input(value, max_length=255):
    if value is None:
        return None
    value = str(value).strip()
    value = value[:max_length]
    # Remove potentially dangerous characters for display
    value = re.sub(r'[<>]', '', value)
    return value

def sanitize_number(value, default=0):
    try:
        return float(value) if value not in (None, "") else default
    except (ValueError, TypeError):
        return default

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user" not in session:
            return redirect("/")
        return f(*args, **kwargs)
    return decorated_function

# CSRF protection
def generate_csrf_token():
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(32)
    return session['csrf_token']

def validate_csrf(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if request.method == "POST":
            token = request.form.get('csrf_token') or request.headers.get('X-CSRF-Token')
            if not token or token != session.get('csrf_token'):
                return jsonify({"error": "Invalid CSRF token"}), 403
        return f(*args, **kwargs)
    return decorated_function

# Make csrf_token available in all templates
@app.context_processor
def inject_csrf_token():
    return dict(csrf_token=generate_csrf_token)


# ================= DATABASE =================
def get_db():
    os.makedirs("instance", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()

    # Centers
    cur.execute("""
        CREATE TABLE IF NOT EXISTS centers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT
        )
    """)

    # Monthly data (with year support)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS monthly_data(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            center_id INTEGER,
            month TEXT,
            year INTEGER DEFAULT 2026,
            revenue REAL DEFAULT 0,
            target REAL DEFAULT 0
        )
    """)

    # Coaches (master list)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS coaches(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            center_id INTEGER,
            name TEXT
        )
    """)

    # Coach salaries per month (with year support)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS coach_salaries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            coach_id INTEGER,
            month TEXT,
            year INTEGER DEFAULT 2026,
            salary REAL DEFAULT 0,
            FOREIGN KEY(coach_id) REFERENCES coaches(id)
        )
    """)

    # Add year column to existing tables if not exists
    try:
        cur.execute("ALTER TABLE monthly_data ADD COLUMN year INTEGER DEFAULT 2026")
    except:
        pass
    try:
        cur.execute("ALTER TABLE coach_salaries ADD COLUMN year INTEGER DEFAULT 2026")
    except:
        pass

    # Ensure at least one center exists
    cur.execute("SELECT COUNT(*) FROM centers")
    if cur.fetchone()[0] == 0:
        cur.execute("INSERT INTO centers(name) VALUES('Center 1')")

    # Users table for secure authentication
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Create default admin user if not exists (change password after first login!)
    cur.execute("SELECT COUNT(*) FROM users WHERE username='admin'")
    if cur.fetchone()[0] == 0:
        default_hash = generate_password_hash("admin", method='pbkdf2:sha256')
        cur.execute("INSERT INTO users(username, password_hash) VALUES(?, ?)", 
                   ("admin", default_hash))

    conn.commit()
    conn.close()


init_db()


# ================= LOGIN =================
@app.route("/", methods=["GET", "POST"])
def login():
    # Check if already logged in
    if "user" in session:
        return redirect("/dashboard")
    
    if request.method == "POST":
        ip = request.remote_addr
        
        # Check if locked out
        if is_locked_out(ip):
            return render_template("login.html", error="Too many attempts. Please wait 5 minutes.")
        
        username = sanitize_input(request.form.get("username", ""), 50)
        password = request.form.get("password", "")
        
        if not username or not password:
            return render_template("login.html", error="Please enter username and password")
        
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT id, password_hash FROM users WHERE username=?", (username,))
        user = cur.fetchone()
        conn.close()
        
        if user and check_password_hash(user["password_hash"], password):
            clear_attempts(ip)
            session.permanent = True
            session["user"] = username
            session["user_id"] = user["id"]
            # Generate CSRF token
            session["csrf_token"] = secrets.token_hex(32)
            return redirect("/dashboard")
        
        record_failed_attempt(ip)
        return render_template("login.html", error="Invalid username or password")

    return render_template("login.html")


# ================= DASHBOARD =================
@app.route("/dashboard", methods=["GET", "POST"])
@login_required
def dashboard():

    conn = get_db()
    cur = conn.cursor()
    month = request.args.get("month", datetime.now().strftime("%B"))
    year = int(request.args.get("year", datetime.now().year))

    # ================= SAFE SAVE =================
    if request.method == "POST":

        # Update center names safely
        for key, val in request.form.items():
            if key.startswith("name"):
                cid = key.replace("name", "")
                cur.execute("UPDATE centers SET name=? WHERE id=?", (val, cid))

        # Save revenue / target without deleting old values
        centers = cur.execute("SELECT id FROM centers").fetchall()

        for c in centers:
            cid = c["id"]

            revenue_raw = request.form.get(f"revenue{cid}")
            target_raw = request.form.get(f"target{cid}")

            cur.execute("""
                SELECT revenue, target FROM monthly_data
                WHERE center_id=? AND month=? AND year=?
            """, (cid, month, year))
            existing = cur.fetchone()

            old_revenue = existing["revenue"] if existing else 0
            old_target = existing["target"] if existing else 0

            revenue = float(revenue_raw) if revenue_raw not in (None, "") else old_revenue
            target = float(target_raw) if target_raw not in (None, "") else old_target

            if existing:
                cur.execute("""
                    UPDATE monthly_data
                    SET revenue=?, target=?
                    WHERE center_id=? AND month=? AND year=?
                """, (revenue, target, cid, month, year))
            else:
                cur.execute("""
                    INSERT INTO monthly_data(center_id, month, year, revenue, target)
                    VALUES(?,?,?,?,?)
                """, (cid, month, year, revenue, target))

        conn.commit()
        
        # If AJAX request, return JSON with updated data
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            # Recalculate centers data
            centers_data = []
            centers = cur.execute("SELECT * FROM centers").fetchall()
            
            # All months for target calculation
            all_months = [
                "January", "February", "March", "April",
                "May", "June", "July", "August",
                "September", "October", "November", "December",
            ]
            
            for c in centers:
                cid = c["id"]
                name = c["name"]
                
                # Apply target formula to ALL months for this center
                for m in all_months:
                    cur.execute("""
                        SELECT id, revenue, target FROM monthly_data
                        WHERE center_id=? AND month=? AND year=?
                    """, (cid, m, year))
                    md_row = cur.fetchone()
                    
                    cur.execute("""
                        SELECT SUM(cs.salary) FROM coach_salaries cs
                        JOIN coaches co ON cs.coach_id = co.id
                        WHERE co.center_id=? AND cs.month=? AND cs.year=?
                    """, (cid, m, year))
                    m_salary = cur.fetchone()[0] or 0
                    
                    calc_target = round(m_salary / 0.299, 2) if m_salary > 0 else 0
                    
                    if md_row:
                        if calc_target > 0:
                            cur.execute("""
                                UPDATE monthly_data SET target=?
                                WHERE center_id=? AND month=? AND year=?
                            """, (calc_target, cid, m, year))
                    elif m_salary > 0:
                        cur.execute("""
                            INSERT INTO monthly_data(center_id, month, year, revenue, target)
                            VALUES(?,?,?,0,?)
                        """, (cid, m, year, calc_target))
                
                conn.commit()
                
                # Get current month data for display
                cur.execute("""
                    SELECT revenue, target FROM monthly_data
                    WHERE center_id=? AND month=? AND year=?
                """, (cid, month, year))
                row = cur.fetchone()
                
                revenue = row["revenue"] if row else 0
                target = row["target"] if row else 0
                
                cur.execute("""
                    SELECT SUM(cs.salary) FROM coach_salaries cs
                    JOIN coaches co ON cs.coach_id = co.id
                    WHERE co.center_id=? AND cs.month=? AND cs.year=?
                """, (cid, month, year))
                salary = cur.fetchone()[0] or 0
                
                achievement = (revenue / target * 100) if target > 0 else 0
                salary_percent = (salary / revenue * 100) if revenue > 0 else 0
                
                centers_data.append({
                    "id": cid,
                    "name": name,
                    "revenue": revenue,
                    "target": target,
                    "achievement": round(achievement, 1),
                    "salary_percent": round(salary_percent, 1)
                })
            
            # Recalculate monthly KPIs
            cur.execute("""
                SELECT month, SUM(revenue) AS total_revenue, SUM(target) AS total_target
                FROM monthly_data
                WHERE year=?
                GROUP BY month
            """, (year,))
            rt_rows = cur.fetchall()
            revenue_target_by_month = {}
            for row in rt_rows:
                revenue_target_by_month[row["month"]] = {
                    "total_revenue": row["total_revenue"] or 0,
                    "total_target": row["total_target"] or 0,
                }
            
            cur.execute("""
                SELECT month, SUM(salary) AS total_salary
                FROM coach_salaries
                WHERE year=?
                GROUP BY month
            """, (year,))
            sal_rows = cur.fetchall()
            salary_by_month = {row["month"]: row["total_salary"] or 0 for row in sal_rows}
            
            calendar_months = [
                "January", "February", "March", "April",
                "May", "June", "July", "August",
                "September", "October", "November", "December",
            ]
            
            monthly_kpis = []
            for m in calendar_months:
                totals = revenue_target_by_month.get(m, {"total_revenue": 0, "total_target": 0})
                total_revenue = totals["total_revenue"] or 0
                total_target = totals["total_target"] or 0
                total_salary = salary_by_month.get(m, 0) or 0
                
                achieved_percent = (total_revenue / total_target * 100) if total_target > 0 else 0
                salary_pct = (total_salary / total_revenue * 100) if total_revenue > 0 else 0
                
                monthly_kpis.append({
                    "month": m,
                    "total_revenue": round(total_revenue, 2),
                    "total_target": round(total_target, 2),
                    "achieved_percent": round(achieved_percent, 1),
                    "salary_percent": round(salary_pct, 1),
                })
            
            conn.close()
            return jsonify({
                "ok": True,
                "centers": centers_data,
                "monthly_kpis": monthly_kpis
            })
        
        return redirect(f"/dashboard?month={month}&year={year}")

    # ================= LOAD =================
    centers_data = []
    centers = cur.execute("SELECT * FROM centers").fetchall()
    
    # All months for target calculation
    all_months = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December",
    ]

    for c in centers:
        cid = c["id"]
        name = c["name"]
        
        # Apply target formula to ALL months for this center
        for m in all_months:
            cur.execute("""
                SELECT id, revenue, target FROM monthly_data
                WHERE center_id=? AND month=? AND year=?
            """, (cid, m, year))
            md_row = cur.fetchone()
            
            cur.execute("""
                SELECT SUM(cs.salary) FROM coach_salaries cs
                JOIN coaches co ON cs.coach_id = co.id
                WHERE co.center_id=? AND cs.month=? AND cs.year=?
            """, (cid, m, year))
            m_salary = cur.fetchone()[0] or 0
            
            # Auto-calculate target (salary should be <= 29.9% of target)
            # Target = salary / 0.299 (ALWAYS update based on salary)
            calc_target = round(m_salary / 0.299, 2) if m_salary > 0 else 0
            
            if md_row:
                # Always update target based on salary formula
                if calc_target > 0:
                    cur.execute("""
                        UPDATE monthly_data SET target=?
                        WHERE center_id=? AND month=? AND year=?
                    """, (calc_target, cid, m, year))
            elif m_salary > 0:
                cur.execute("""
                    INSERT INTO monthly_data(center_id, month, year, revenue, target)
                    VALUES(?,?,?,0,?)
                """, (cid, m, year, calc_target))
        
        conn.commit()

        # Now get current month data for display
        cur.execute("""
            SELECT revenue, target FROM monthly_data
            WHERE center_id=? AND month=? AND year=?
        """, (cid, month, year))
        row = cur.fetchone()

        revenue = row["revenue"] if row else 0
        target = row["target"] if row else 0

        cur.execute("""
            SELECT SUM(cs.salary) FROM coach_salaries cs
            JOIN coaches c ON cs.coach_id = c.id
            WHERE c.center_id=? AND cs.month=? AND cs.year=?
        """, (cid, month, year))
        salary = cur.fetchone()[0] or 0

        achievement = (revenue / target * 100) if target > 0 else 0
        salary_percent = (salary / revenue * 100) if revenue > 0 else 0

        centers_data.append({
            "id": cid,
            "name": name,
            "revenue": revenue,
            "target": target,
            "achievement": round(achievement, 1),
            "salary_percent": round(salary_percent, 1)
        })

    # ================= MONTHLY KPI (CALENDAR VIEW) =================
    # Aggregate total revenue and target per month across all centers for selected year
    cur.execute("""
        SELECT month, SUM(revenue) AS total_revenue, SUM(target) AS total_target
        FROM monthly_data
        WHERE year=?
        GROUP BY month
    """, (year,))
    rt_rows = cur.fetchall()

    revenue_target_by_month = {}
    for row in rt_rows:
        revenue_target_by_month[row["month"]] = {
            "total_revenue": row["total_revenue"] or 0,
            "total_target": row["total_target"] or 0,
        }

    # Aggregate total salary per month across all centers for selected year
    cur.execute("""
        SELECT month, SUM(salary) AS total_salary
        FROM coach_salaries
        WHERE year=?
        GROUP BY month
    """, (year,))
    sal_rows = cur.fetchall()

    salary_by_month = {}
    for row in sal_rows:
        salary_by_month[row["month"]] = row["total_salary"] or 0

    # Build ordered list of months like a calendar (Jan–Dec)
    calendar_months = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December",
    ]

    monthly_kpis = []
    for m in calendar_months:
        totals = revenue_target_by_month.get(m, {"total_revenue": 0, "total_target": 0})
        total_revenue = totals["total_revenue"] or 0
        total_target = totals["total_target"] or 0
        total_salary = salary_by_month.get(m, 0) or 0

        achieved_percent = (total_revenue / total_target * 100) if total_target > 0 else 0
        salary_percent = (total_salary / total_revenue * 100) if total_revenue > 0 else 0

        monthly_kpis.append({
            "month": m,
            "total_revenue": round(total_revenue, 2),
            "total_target": round(total_target, 2),
            "achieved_percent": round(achieved_percent, 1),
            "salary_percent": round(salary_percent, 1),
        })

    conn.close()

    return render_template(
        "dashboard.html",
        centers=centers_data,
        month=month,
        year=year,
        monthly_kpis=monthly_kpis
    )


# ================= CENTERS MANAGEMENT (ADD / DELETE) =================
@app.route("/center/add", methods=["POST"])
@login_required
def add_center():
    name = sanitize_input(request.form.get("name")) or "New Center"
    month = request.args.get("month", datetime.now().strftime("%B"))
    year = request.args.get("year", datetime.now().year)

    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO centers(name) VALUES(?)", (name,))
    conn.commit()
    conn.close()

    return redirect(f"/dashboard?month={month}&year={year}")


@app.route("/center/delete/<int:center_id>")
@login_required
def delete_center(center_id):
    month = request.args.get("month", datetime.now().strftime("%B"))
    year = request.args.get("year", datetime.now().year)

    conn = get_db()
    cur = conn.cursor()

    # Cascade delete: remove all related monthly data, coach salaries and coaches first
    cur.execute("DELETE FROM monthly_data WHERE center_id=?", (center_id,))
    cur.execute("""
        DELETE FROM coach_salaries WHERE coach_id IN 
        (SELECT id FROM coaches WHERE center_id=?)
    """, (center_id,))
    cur.execute("DELETE FROM coaches WHERE center_id=?", (center_id,))
    cur.execute("DELETE FROM centers WHERE id=?", (center_id,))

    conn.commit()
    conn.close()

    return redirect(f"/dashboard?month={month}&year={year}")


# ================= COACHES =================
@app.route("/coaches", methods=["GET", "POST"])
@login_required
def coaches():
    conn = get_db()
    cur = conn.cursor()
    month = request.args.get("month", datetime.now().strftime("%B"))
    year = int(request.args.get("year", datetime.now().year))
    selected_center = request.args.get("center")  # Filter by center
    if selected_center:
        selected_center = int(selected_center)
    
    if request.method == "POST":
        action = request.form.get("action")
        
        if action == "add_coach":
            # Add new coach
            cur.execute("""
                INSERT INTO coaches(name, center_id)
                VALUES(?,?)
            """, (
                request.form["name"],
                request.form["center_id"]
            ))
            conn.commit()
            
        elif action == "update_salary":
            # Update salary for a specific coach and month
            coach_id = request.form.get("coach_id")
            salary_month = request.form.get("salary_month")
            salary_year = int(request.form.get("salary_year", year))
            salary = float(request.form.get("salary") or 0)
            
            # Check if salary record exists
            cur.execute("""
                SELECT id FROM coach_salaries 
                WHERE coach_id=? AND month=? AND year=?
            """, (coach_id, salary_month, salary_year))
            existing = cur.fetchone()
            
            if existing:
                cur.execute("""
                    UPDATE coach_salaries SET salary=?
                    WHERE coach_id=? AND month=? AND year=?
                """, (salary, coach_id, salary_month, salary_year))
            else:
                cur.execute("""
                    INSERT INTO coach_salaries(coach_id, month, year, salary)
                    VALUES(?,?,?,?)
                """, (coach_id, salary_month, salary_year, salary))
            conn.commit()
            
            # Auto-update target based on total salary for the center (ALL MONTHS)
            # Get center_id for this coach
            cur.execute("SELECT center_id FROM coaches WHERE id=?", (coach_id,))
            coach_row = cur.fetchone()
            if coach_row:
                center_id = coach_row["center_id"]
                
                # Apply to ALL months
                all_months = [
                    "January", "February", "March", "April",
                    "May", "June", "July", "August",
                    "September", "October", "November", "December",
                ]
                
                for m in all_months:
                    # Calculate total salary for this center, month, year
                    cur.execute("""
                        SELECT SUM(cs.salary) as total_salary
                        FROM coach_salaries cs
                        JOIN coaches co ON cs.coach_id = co.id
                        WHERE co.center_id=? AND cs.month=? AND cs.year=?
                    """, (center_id, m, salary_year))
                    total_salary = cur.fetchone()["total_salary"] or 0
                    
                    # Calculate target (salary should be <= 29.9% of target)
                    calc_target = round(total_salary / 0.299, 2) if total_salary > 0 else 0
                    
                    # Check if monthly_data exists for this center/month/year
                    cur.execute("""
                        SELECT id, target FROM monthly_data
                        WHERE center_id=? AND month=? AND year=?
                    """, (center_id, m, salary_year))
                    md_row = cur.fetchone()
                    
                    if md_row:
                        if calc_target > 0:
                            cur.execute("""
                                UPDATE monthly_data SET target=?
                                WHERE center_id=? AND month=? AND year=?
                            """, (calc_target, center_id, m, salary_year))
                    elif total_salary > 0:
                        cur.execute("""
                            INSERT INTO monthly_data(center_id, month, year, revenue, target)
                            VALUES(?,?,?,0,?)
                        """, (center_id, m, salary_year, calc_target))
                
                conn.commit()
            
        elif action == "edit_coach":
            # Update coach name and center
            coach_id = request.form.get("coach_id")
            cur.execute("""
                UPDATE coaches SET name=?, center_id=?
                WHERE id=?
            """, (
                request.form["name"],
                request.form["center_id"],
                coach_id
            ))
            conn.commit()
        
        return redirect(f"/coaches?month={month}&year={year}")

    # Get all coaches with their current month salary
    cur.execute("""
        SELECT c.id, c.name, c.center_id, 
               COALESCE(cs.salary, 0) as salary
        FROM coaches c
        LEFT JOIN coach_salaries cs ON c.id = cs.coach_id AND cs.month = ? AND cs.year = ?
    """, (month, year))
    coaches_list = cur.fetchall()
    
    centers = cur.execute("SELECT * FROM centers").fetchall()

    # Get all salaries for all coaches (for calendar view) - filtered by year
    cur.execute("""
        SELECT coach_id, month, salary FROM coach_salaries WHERE year=?
    """, (year,))
    all_salaries = cur.fetchall()
    
    # Build salary lookup: {coach_id: {month: salary}}
    salary_by_coach = {}
    for row in all_salaries:
        cid = row["coach_id"]
        if cid not in salary_by_coach:
            salary_by_coach[cid] = {}
        salary_by_coach[cid][row["month"]] = row["salary"]

    # Monthly total salary across all coaches (for top calendar) - filtered by year
    cur.execute("""
        SELECT month, SUM(salary) AS total_salary
        FROM coach_salaries
        WHERE year=?
        GROUP BY month
    """, (year,))
    sal_rows = cur.fetchall()

    salary_by_month = {row["month"]: row["total_salary"] or 0 for row in sal_rows}

    calendar_months = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December",
    ]

    monthly_salary = []
    for m in calendar_months:
        total_salary = salary_by_month.get(m, 0) or 0
        monthly_salary.append({
            "month": m,
            "total_salary": round(total_salary, 2),
        })

    conn.close()

    return render_template(
        "coaches.html",
        coaches=coaches_list,
        centers=centers,
        month=month,
        year=year,
        monthly_salary=monthly_salary,
        calendar_months=calendar_months,
        salary_by_coach=salary_by_coach,
        selected_center=selected_center,
    )


# ================= DELETE COACH =================
@app.route("/delete_coach/<int:coach_id>")
@login_required
def delete_coach(coach_id):
    month = request.args.get("month", datetime.now().strftime("%B"))
    year = request.args.get("year", datetime.now().year)
    
    conn = get_db()
    cur = conn.cursor()
    
    # Delete all salary records for this coach
    cur.execute("DELETE FROM coach_salaries WHERE coach_id=?", (coach_id,))
    cur.execute("DELETE FROM coaches WHERE id=?", (coach_id,))
    conn.commit()
    conn.close()
    
    return redirect(f"/coaches?month={month}&year={year}")


# ================= ANALYTICS =================
@app.route("/analytics")
@login_required
def analytics():
    conn = get_db()
    cur = conn.cursor()
    year = int(request.args.get("year", datetime.now().year))

    calendar_months = [
        "January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December",
    ]

    # Get revenue and target per month for selected year
    cur.execute("""
        SELECT month, SUM(revenue) AS total_revenue, SUM(target) AS total_target
        FROM monthly_data
        WHERE year=?
        GROUP BY month
    """, (year,))
    rt_rows = cur.fetchall()
    revenue_target_by_month = {}
    for row in rt_rows:
        revenue_target_by_month[row["month"]] = {
            "total_revenue": row["total_revenue"] or 0,
            "total_target": row["total_target"] or 0,
        }

    # Get salary per month for selected year
    cur.execute("""
        SELECT month, SUM(salary) AS total_salary
        FROM coach_salaries
        WHERE year=?
        GROUP BY month
    """, (year,))
    sal_rows = cur.fetchall()
    salary_by_month = {row["month"]: row["total_salary"] or 0 for row in sal_rows}

    # Build analytics data
    analytics_data = []
    total_revenue = 0
    total_target = 0
    total_salary = 0

    for m in calendar_months:
        totals = revenue_target_by_month.get(m, {"total_revenue": 0, "total_target": 0})
        revenue = totals["total_revenue"] or 0
        target = totals["total_target"] or 0
        salary = salary_by_month.get(m, 0) or 0

        achieved = round((revenue / target * 100), 1) if target > 0 else 0
        salary_ratio = round((salary / revenue * 100), 1) if revenue > 0 else 0
        profit = revenue - salary

        total_revenue += revenue
        total_target += target
        total_salary += salary

        analytics_data.append({
            "month": m,
            "revenue": revenue,
            "target": target,
            "achieved": achieved,
            "salary_ratio": salary_ratio,
            "profit": profit,
        })

    # Calculate growth data (month-to-month)
    growth_data = []
    for i, data in enumerate(analytics_data):
        if i == 0:
            growth = 0
        else:
            prev_revenue = analytics_data[i - 1]["revenue"]
            if prev_revenue > 0:
                growth = round(((data["revenue"] - prev_revenue) / prev_revenue) * 100, 1)
            else:
                growth = 0

        direction = "📈" if growth > 0 else ("📉" if growth < 0 else "➡️")
        growth_data.append({
            "month": data["month"],
            "growth": growth,
            "direction": direction,
        })

    # Calculate averages
    avg_achievement = round(sum(d["achieved"] for d in analytics_data) / 12, 1)

    conn.close()

    return render_template(
        "analytics.html",
        analytics_data=analytics_data,
        growth_data=growth_data,
        total_revenue=total_revenue,
        total_target=total_target,
        avg_achievement=avg_achievement,
        year=year,
    )


# ================= LOGOUT =================
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


# ===== ADD 6 CENTERS AUTO =====
if __name__ == "__main__":
    conn = get_db()
    cur = conn.cursor()

    extra_centers = [
    ]

    for name in extra_centers:
        cur.execute("SELECT id FROM centers WHERE name=?", (name,))
        if not cur.fetchone():
            cur.execute("INSERT INTO centers(name) VALUES(?)", (name,))

    conn.commit()
    conn.close()

    app.run(debug=True)



















